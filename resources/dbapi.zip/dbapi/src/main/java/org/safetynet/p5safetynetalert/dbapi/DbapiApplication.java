package org.safetynet.p5safetynetalert.dbapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbapiApplication.class, args);
	}

}
